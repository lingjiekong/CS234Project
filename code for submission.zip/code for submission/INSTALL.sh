sudo pip3 install -U git+https://github.com/ppwwyyxx/tensorpack.git
sudo pip3 install opencv-python
sudo pip3 install tornado
sudo pip3 install --upgrade tensorflow-gpu==1.4
sudo pip3 install cmake
sudo pip3 install zlib1g-dev
sudo pip3 install gym[atari]
sudo pip3 install ffmpeg