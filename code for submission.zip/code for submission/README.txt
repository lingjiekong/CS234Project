- run gpu-setup-part1 and gpu-setup-part2 bash shell from CS234 website to install CUDA and cudnn
- run install to install tensorflow and other for python3
- tensorpack can be downdloaded from https://github.com/ppwwyyxx/tensorpack
- edit file train-atari.py under \tensorpack-master\examples\A3C-Gym to double-train-atari, and shared double-train-atari



